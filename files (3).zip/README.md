# Society of Capital Design, website

Five sheet static site. No build step, no database, no accounts to
pay for. Every page is one html file, edited right on GitHub in your
browser and published free by GitHub Pages.

## Publish (one time)
Repo Settings, then Pages: Source = Deploy from a branch, Branch =
main, folder = / (root), Save. The live URL appears in a minute.

## Edit from anywhere
1. Open the file on github.com and click the pencil icon.
2. Search the file for the word EDIT to jump to a FOUNDERS EDIT ZONE.
3. Change what you need using the template in the comment.
4. Commit changes. GitHub Pages republishes by itself.

To add a photo or Bulletin PDF: Add file, Upload files, then link to
it by its exact filename inside the relevant EDIT ZONE.

## Files
* index.html, about.html, events.html, newsletter.html, join.html:
  the five sheets
* scd-logo.jpg: the logo, used in every header
* challenge-section-SAVED-FOR-LATER.html: the Capital Design
  Challenge section, ready to paste into events.html when scheduled
* HOW-TO-EDIT.txt: the full editing guide and publishing rules
